# Steaming data from Twitter

This example demonstrates Node.js streaming data from the streaming Twitter API using [nTwitter][1]

Install dependencies with 

    npm install

Start the application with 

    node app.js

[1]: https://github.com/AvianFlu/ntwitter

