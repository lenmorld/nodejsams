# Making sense of data

This example demonstrates how to make the data more consumable by doing some simple calculations on the server

Install dependencies with 

    npm install

Start the application with 

    node app.js
