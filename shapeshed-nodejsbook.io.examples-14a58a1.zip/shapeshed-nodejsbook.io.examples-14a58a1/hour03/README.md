# Chapter 3

Chapter 3 explores what Node.js was designed for.

