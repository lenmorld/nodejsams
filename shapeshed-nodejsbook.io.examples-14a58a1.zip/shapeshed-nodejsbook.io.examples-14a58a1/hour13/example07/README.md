# Node.js Socket.io Chat Server

This is an example chat server created with Express and Socket.io.

## Installation

Clone the git repo then run

    npm install 

Start the server with

    node app.js

Open a browser at http://127.0.0.1:3000/

