# Sending Nicknames to the server

This example demonstrates how to send nicknames to the server

Install dependencies with 

    npm install

Start the application with 

    node app.js

Open a browser at http://127.0.0.1:3000 and enter a nickname into the form. Click submit. In the server logs you should see that your nickname has been received by the server. 

