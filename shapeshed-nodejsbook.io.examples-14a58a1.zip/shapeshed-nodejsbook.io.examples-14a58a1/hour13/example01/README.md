# Socket.io Express Example

This example demonstrates how to use Socket.io with Express.

Install dependencies with 

    npm install

Start the application with 

    node app.js

Open a browser at http://127.0.0.1:3000 and open the JavaScript console for the browser. You should see 'OH HAI! U R CONNECTED!' meaning you are connected to the Socket.io server and have received a message from it.

