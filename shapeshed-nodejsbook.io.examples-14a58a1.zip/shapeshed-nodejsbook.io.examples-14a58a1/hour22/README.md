# Chapter 22

Chapter 22 shows how to create Node.js modules and share them.

1. A package.json file 
2. Folder layout for a Node.js module
3. How to test your module with assert 
4. How to test your module with mocha
5. Adding an execuable to your module
6. Using module.exports with prototype-based programming
7. Using module.exports with privileged methods
8. Adding Travis CI, Github Information and publishing to npm
