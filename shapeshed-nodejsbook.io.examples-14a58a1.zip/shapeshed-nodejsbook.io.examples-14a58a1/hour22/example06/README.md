# Using module.exports

This example demonstrates using `module.exports` when using a prototype-based programming style.
