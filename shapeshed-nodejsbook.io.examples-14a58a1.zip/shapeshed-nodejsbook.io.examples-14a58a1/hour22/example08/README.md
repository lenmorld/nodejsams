# Adding Travis CI, Github Information and publishing to npm 

This example shows how to add Travis CI to the project and adds repository information to the package.json file.


