# Using module.exports

This example demonstrates using `module.exports` when using an Object Orientated Programming style and privileged methods.
