# Nodester was acquired by AppFog

Nodester was acquired by [AppFog][1] so this example is no longer relevant.

[1]: https://www.appfog.com/
