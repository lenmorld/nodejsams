# Chapter 5

Chapter 5 explores The [HTTP module][1] in node.js.

1. Basic Hello World Server
2. Adding a response code and Header
3. Creating a redirect
4. Responding to more than one type of request
5. An HTTP client with node.js
6. Daemonising the HTTP client

[1]: http://nodejs.org/docs/latest/api/http.html

