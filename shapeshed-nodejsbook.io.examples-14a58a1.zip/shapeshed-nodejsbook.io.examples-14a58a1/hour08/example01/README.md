# Writing data to a file

This example illustrates writing data to a file in Node.js.

To run the example run

    node app.js

A file named `file.txt` will be created and the data will be written to it. 


