# Reading data from a file

This example illustrates reading data from a file in Node.js.

To run the example run

    node app.js

The script will read the data from the `file.txt` file and output it to the terminal.

