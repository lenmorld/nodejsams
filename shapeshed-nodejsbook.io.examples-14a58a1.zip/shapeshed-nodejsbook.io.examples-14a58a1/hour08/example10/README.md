# Flash is no longer part of Express

Flash was removed from Express and is now supported by third party modules. None of these were found to be very well maintained or stable so these examples are now deprecated and do not feature flash messages.

If you are keen on flash messages I suggest searching npm for ['flash express connect'][1].

[1]: https://npmjs.org/search?q=flash+express+connect
