# Twitter have remove the search API

Twitter have removed the search API so this example no longer works
